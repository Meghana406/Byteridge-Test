import React from 'react';
import moment from 'moment';
import { Link } from 'react-router-dom';
import { connect } from 'react-redux';
import { userActions } from '../_actions';
// import ReactDataTablePagination from 'react-datatable-pagination'
import { Navbar, Nav } from 'react-bootstrap';


class Auditpage extends React.Component {
    constructor(props){
        super(props)
        this.state = {
            value:'coco',
            offset:0,
            tableData:[],
            orgtabeData:[],
            perPage:5,
            currentPage: 0,
            search:null
        }
      this.changeDate = this.changeDate.bind(this);
    }


    componentDidMount() {
        this.props.getUsers();
    }
    searchSpace(e){
        let keyword = e.target.value;
        this.setState({search:keyword})
    }

    filterProducts(e){
        alert("value")
    }

    changeDate(date){
        var dt = new Date(date);
        var date1 = dt.toLocaleString();
        var dd = dt.getDate();

        var mm = dt.getMonth()+1; 
        var yyyy = dt.getFullYear();
        var hours = dt.getHours();
        var minutes = dt.getMinutes();
        var sec = dt.getSeconds();
        var dt1 = dd+'/'+mm+'/'+ yyyy+" "+hours+":"+minutes+":"+sec;
        return dt1;

    }



    handleDeleteUser(id) {
        return (e) => this.props.deleteUser(id);
    }


    render() {
        console.log(this.changeDate('2020-12-14T02:52:14.214Z'))
        const { user, users } = this.props;
        const styleInfo = {
            paddingRight:'10px'
          }
          const elementStyle ={
            border:'solid',
            borderRadius:'10px',
            position:'relative',
            left:'10vh',
            height:'3vh',
            width:'20vh',
            marginTop:'5vh',
            marginBottom:'10vh'
          }
          const items = users.items && users.items.filter((data)=>{
            if(this.state.search == null)
                return data
            else if(data.role.toLowerCase().includes(this.state.search.toLowerCase()) || data.firstName.toLowerCase().includes(this.state.search.toLowerCase())){
                return data
            }

          })
          .map((data,index)=>{
            return(
            <div>
                <table border="1">
                     {/* <thead>
                         <th>Id</th>
                         <th>Role</th>
                         <th>CreatedDate</th>
                         <th>FirstName</th>
                         <th>Lastname</th>
                         <th>Delete</th>

                     </thead> */}
                     <tbody>
                     <tr key={index}>
                        <td>{data.id}</td>
                        <td>{data.role}</td>
                        <td>{data.firstName}</td>
                        <td>{this.changeDate(data.createdDate)}</td>
                        <td>{data.lastName}</td>
                        <td> {
                                        data.deleting ? <em> - Deleting...</em>
                                            : data.deleteError ? <span className="text-danger"> - ERROR: {data.deleteError}</span>
                                                : <span> - <a onClick={this.handleDeleteUser(data.id)}>Delete</a></span>
                                    }</td>
                    </tr>

                     </tbody>

                </table>

            </div>
            )
          })
      
        return (
            <div>
                <Navbar bg="dark" variant="dark">
                    <Navbar.Brand ></Navbar.Brand>
                    <Nav className="mr-auto">
                        <Nav.Link ><Link to="/">Home</Link></Nav.Link>
                        <Nav.Link href="#features">Auditor</Nav.Link>
                        <Nav.Link> <Link to="/login">Logout</Link></Nav.Link>
                    </Nav>
                </Navbar>
                <div className="col-md-6 col-md-offset-3">

                    <h1>Hi {user.firstName}!</h1>
                    <p>You're logged in with React!!</p>
                    <h3>All login audit :</h3>
                    {users.loading && <em>Loading users...</em>}
                    {users.error && <span className="text-danger">ERROR: {users.error}</span>}
                    <div>
                        <select>
                            <option value="12" onClick={this.filterProducts.bind(this)}>12hrs</option>
                            <option value="24">24hrs</option>
                        </select>
                        <input type="text" placeholder="search" style={elementStyle} onChange={(e)=>this.searchSpace(e)}/>
                    {/* <ReactDataTablePagination arrayOfObjects={users.items?users.items:""} dataInOnePage={5}/> */}
                    {items}
                    <table border="1">
                     <thead>
                         <th>Id</th>
                         <th>Role</th>
                         <th>CreatedDate</th>
                         <th>FirstName</th>
                         <th>Lastname</th>
                         <th>Delete</th>

                     </thead>
                     <tbody>
                         {users.items && users.items.map((user,index) =>{
                             return(
                                 <tr key={index}>
                                     <td>{user.id}</td>
                                     <td>{user.role}</td>
                                     <td>{this.changeDate(user.createdDate)}</td>
                                     <td>{user.firstName}</td>
                                     <td>{user.lastName}</td>
                                     <td> {
                                        user.deleting ? <em> - Deleting...</em>
                                            : user.deleteError ? <span className="text-danger"> - ERROR: {user.deleteError}</span>
                                                : <span> - <a onClick={this.handleDeleteUser(user.id)}>Delete</a></span>
                                    }</td>
                                 </tr>
                             )
                        })}

                     </tbody>
                    {/* {users.items &&
                        <ul className="user-screen">
                            {users.items.map((user, index) =>
                                <li key={user.id}>
                                    {user.id + ' ' + user.role + ' ' + user.createdDate + ' '}
                                    {user.firstName + ' ' + user.lastName}
                                    {
                                        user.deleting ? <em> - Deleting...</em>
                                            : user.deleteError ? <span className="text-danger"> - ERROR: {user.deleteError}</span>
                                                : <span> - <a onClick={this.handleDeleteUser(user.id)}>Delete</a></span>
                                    }
                                </li>
                            )}

                        </ul>
                    } */}
                </table>
                </div>
                </div>
            </div>
        );
    }
}

function mapState(state) {
    const { users, authentication } = state;
    const { user } = authentication;
    return { user, users };
}

const actionCreators = {
    getUsers: userActions.getAll,
    deleteUser: userActions.delete
}

const connectedAuditPage = connect(mapState, actionCreators)(Auditpage);
export { connectedAuditPage as Auditpage };